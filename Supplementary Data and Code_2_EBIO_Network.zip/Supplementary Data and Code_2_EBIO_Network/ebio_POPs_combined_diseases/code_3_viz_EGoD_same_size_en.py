#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
EGoD Network Visualization Script
Read edges and nodes files, draw network graph
"""

import os
import sys
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
import networkx as nx
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

# Set UTF-8 encoding for output
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# Set English font
plt.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans', 'Liberation Sans']
plt.rcParams['axes.unicode_minus'] = False

# Ignore warnings
warnings.filterwarnings('ignore')

# Auto-detect folders starting with ebio_summary_
current_dir = os.getcwd()
ebio_folders = [f for f in os.listdir(current_dir) 
                if os.path.isdir(os.path.join(current_dir, f)) and f.startswith('ebio_summary_')]

if not ebio_folders:
    print("Error: Folder starting with 'ebio_summary_' not found")
    sys.exit(1)

# Use the first ebio_summary_ folder found
ebio_folder = ebio_folders[0]
print(f"Folder found: {ebio_folder}")

# File paths
base_dir = os.path.join(ebio_folder, 'buildModel')
if not os.path.exists(base_dir):
    print(f"Error: buildModel folder does not exist in {ebio_folder}")
    sys.exit(1)

edges_file = os.path.join(base_dir, 'EGoD_edges_corrected.csv')
nodes_file = os.path.join(base_dir, 'EGoD_nodes_corrected.csv')
output_dir = os.path.join("results_viz_ebio", 'viz_EGoD/set_node_same_size')

# Create output directory
os.makedirs(output_dir, exist_ok=True)

print("="*50)
print("EGoD Network Visualization")
print("="*50)

# Read data
print("\nReading edge data...")
edges_df = pd.read_csv(edges_file)
print(f"Edge data shape: {edges_df.shape}")
print(f"Edge data columns: {edges_df.columns.tolist()}")
print(f"Number of edges: {len(edges_df)}")

print("\nReading node data...")
nodes_df = pd.read_csv(nodes_file)
print(f"Node data shape: {nodes_df.shape}")
print(f"Node data columns: {nodes_df.columns.tolist()}")
print(f"Number of nodes: {len(nodes_df)}")

# Check required columns
if 'Source' not in edges_df.columns or 'Target' not in edges_df.columns:
    print("Error: edges file missing Source or Target column")
    sys.exit(1)

if 'Group name' not in nodes_df.columns:
    print("Error: nodes file missing Group name column")
    sys.exit(1)

# Get node ID column name (usually first column or 'Id')
node_id_col = nodes_df.columns[0] if 'Id' not in nodes_df.columns else 'Id'
print(f"\nUsing node ID column: {node_id_col}")

# Create network graph
print("\nCreating network graph...")
G = nx.Graph()

# Add edges
for _, row in edges_df.iterrows():
    G.add_edge(row['Source'], row['Target'])

print(f"Network nodes: {G.number_of_nodes()}")
print(f"Network edges: {G.number_of_edges()}")

# Create node to group and name mapping
node_to_group = {}
node_to_name = {}
for _, row in nodes_df.iterrows():
    node_id = row[node_id_col]
    group = row['Group name']
    preferred_name = row['Preferred name'] if pd.notna(row['Preferred name']) else str(node_id)
    node_to_group[node_id] = group
    node_to_name[node_id] = preferred_name

# Get all unique groups
unique_groups = nodes_df['Group name'].unique()
print(f"\nNumber of groups: {len(unique_groups)}")
print(f"Group list: {unique_groups.tolist()}")

# Assign fixed colors for each group: Exposure=blue, GO=green, Disease=red
group_to_color = {
    'Exposure': (0.2, 0.4, 0.8),   # Blue
    'GO': (0.2, 0.7, 0.3),         # Green
    'Disease': (0.9, 0.2, 0.2)     # Red
}

# Assign colors to nodes
node_colors = []
for node in G.nodes():
    group = node_to_group.get(node, 'Unknown')
    node_colors.append(group_to_color.get(group, (0.5, 0.5, 0.5)))

# Draw network graph
print("\nDrawing network graph...")

# Figure 1: Using spring layout
plt.figure(figsize=(20, 16))
pos = nx.spring_layout(G, k=2, iterations=50, seed=42)

nx.draw_networkx_nodes(G, pos, 
                       node_color=node_colors,
                       node_size=100,
                       alpha=0.8)

nx.draw_networkx_edges(G, pos, 
                       alpha=0.025,
                       width=1)

# Use preferred name as label
labels = {node: node_to_name.get(node, str(node)) for node in G.nodes()}
nx.draw_networkx_labels(G, pos, 
                        labels=labels,
                        font_size=8,
                        font_color='grey',
                        alpha=0.5)

# Add legend - using circular markers
legend_elements = [Line2D([0], [0], marker='o', color='w', 
                         markerfacecolor=group_to_color[group],
                         markersize=10, label=group, alpha=0.8) 
                  for group in unique_groups]
plt.legend(handles=legend_elements, 
          loc='upper left', 
          fontsize=10,
          title='Group Name')

plt.title('EGoD Network Visualization (Spring Layout)', fontsize=16, pad=20)
plt.axis('off')
plt.tight_layout()

output_file1 = os.path.join(output_dir, 'EGoD_network_spring.png')
plt.savefig(output_file1, dpi=300, bbox_inches='tight')
print(f"Spring layout network graph saved: {output_file1}")
plt.close()

# Figure 2: Using kamada_kawai layout
plt.figure(figsize=(20, 16))
try:
    pos = nx.kamada_kawai_layout(G)
    
    nx.draw_networkx_nodes(G, pos, 
                           node_color=node_colors,
                           node_size=100,
                           alpha=0.8)
    
    nx.draw_networkx_edges(G, pos, 
                           alpha=0.025,
                           width=1)
    
    # Use preferred name as label
    nx.draw_networkx_labels(G, pos, 
                            labels=labels,
                            font_size=8,
                            font_color='grey',
                            alpha=0.5)
    
    # Add legend
    plt.legend(handles=legend_elements, 
              loc='upper left', 
              fontsize=10,
              title='Group Name')
    
    plt.title('EGoD Network Visualization (Kamada-Kawai Layout)', fontsize=16, pad=20)
    plt.axis('off')
    plt.tight_layout()
    
    output_file2 = os.path.join(output_dir, 'EGoD_network_kamada_kawai.png')
    plt.savefig(output_file2, dpi=300, bbox_inches='tight')
    print(f"Kamada-Kawai layout network graph saved: {output_file2}")
    plt.close()
except:
    print("Kamada-Kawai layout failed, skipping")

# Figure 3: Using circular layout (by group)
plt.figure(figsize=(20, 16))

# Sort nodes by group
nodes_by_group = {}
for node in G.nodes():
    group = node_to_group.get(node, 'Unknown')
    if group not in nodes_by_group:
        nodes_by_group[group] = []
    nodes_by_group[group].append(node)

# Create circular layout by group
pos = {}
angle_step = 2 * np.pi / len(G.nodes())
current_angle = 0

for group in unique_groups:
    if group in nodes_by_group:
        for node in nodes_by_group[group]:
            pos[node] = (np.cos(current_angle), np.sin(current_angle))
            current_angle += angle_step

nx.draw_networkx_nodes(G, pos, 
                       node_color=node_colors,
                       node_size=100,
                       alpha=0.8)

nx.draw_networkx_edges(G, pos, 
                       alpha=0.025,
                       width=1)

# Use preferred name as label
nx.draw_networkx_labels(G, pos, 
                        labels=labels,
                        font_size=8,
                        font_color='grey',
                        alpha=0.5)

# Add legend
plt.legend(handles=legend_elements, 
          loc='upper left', 
          fontsize=10,
          title='Group Name')

plt.title('EGoD Network Visualization (Circular Layout)', fontsize=16, pad=20)
plt.axis('off')
plt.tight_layout()

output_file3 = os.path.join(output_dir, 'EGoD_network_circular.png')
plt.savefig(output_file3, dpi=300, bbox_inches='tight')
print(f"Circular layout network graph saved: {output_file3}")
plt.close()

# Figure 4: Using layered circular layout (Outer: Exposure, Middle: GO, Inner: Disease)
plt.figure(figsize=(20, 16))

# Assign to different circular layers by group
exposure_nodes = nodes_by_group.get('Exposure', [])
go_nodes = nodes_by_group.get('GO', [])
disease_nodes = nodes_by_group.get('Disease', [])

pos = {}

# Outermost layer: Exposure (compounds) - radius 3
if exposure_nodes:
    n_exposure = len(exposure_nodes)
    for i, node in enumerate(exposure_nodes):
        angle = 2 * np.pi * i / n_exposure
        pos[node] = (3 * np.cos(angle), 3 * np.sin(angle))

# Middle layer: GO (gene ontology) - radius 2
if go_nodes:
    n_go = len(go_nodes)
    for i, node in enumerate(go_nodes):
        angle = 2 * np.pi * i / n_go
        pos[node] = (2 * np.cos(angle), 2 * np.sin(angle))

# Innermost layer: Disease - ALL diseases at center (0, 0)
if disease_nodes:
    print(f"\n=== Disease Nodes Debug ===")
    print(f"Total disease nodes: {len(disease_nodes)}")
    for node in disease_nodes:
        node_name = node_to_name.get(node, str(node))
        print(f"  Disease node: {node_name} (ID: {node})")
    
    # Place ALL disease nodes at exact center (0, 0)
    for node in disease_nodes:
        pos[node] = (0.0, 0.0)
        print(f"  -> Placed at center (0, 0): {node_to_name.get(node, node)}")
    print(f"=========================\n")

nx.draw_networkx_nodes(G, pos, 
                       node_color=node_colors,
                       node_size=100,
                       alpha=0.8)

nx.draw_networkx_edges(G, pos, 
                       alpha=0.025,
                       width=1)

# Use preferred name as label
nx.draw_networkx_labels(G, pos, 
                        labels=labels,
                        font_size=8,
                        font_color='grey',
                        alpha=0.5)

# Add legend
plt.legend(handles=legend_elements, 
          loc='upper left', 
          fontsize=10,
          title='Group Name')

# Add circular guide lines
circle0 = plt.Circle((0, 0), 0.5, color='gray', fill=False, linestyle='--', linewidth=1, alpha=0.025)
circle1 = plt.Circle((0, 0), 1, color='gray', fill=False, linestyle='--', linewidth=1, alpha=0.025)
circle2 = plt.Circle((0, 0), 2, color='gray', fill=False, linestyle='--', linewidth=1, alpha=0.025)
circle3 = plt.Circle((0, 0), 3, color='gray', fill=False, linestyle='--', linewidth=1, alpha=0.025)
plt.gca().add_patch(circle0)
plt.gca().add_patch(circle1)
plt.gca().add_patch(circle2)
plt.gca().add_patch(circle3)

# Add layer annotations
plt.text(0, 3.3, 'Exposure (Outer)', ha='center', fontsize=12, fontweight='bold')
plt.text(0, 2.3, 'GO (Middle)', ha='center', fontsize=12, fontweight='bold')
plt.text(0, 1.3, 'Disease (Inner)', ha='center', fontsize=12, fontweight='bold')
plt.text(0, 0.7, 'EX:D (Center)', ha='center', fontsize=10, fontweight='bold', color='darkred')

plt.title('EGoD Network Visualization (Layered Circular Layout)\nOuter: Exposure, Middle: GO, Inner: Disease', 
          fontsize=16, pad=20)

# Force symmetric axis limits to center the plot at (0,0)
max_radius = 3.5  # Slightly larger than outermost layer
plt.xlim(-max_radius, max_radius)
plt.ylim(-max_radius, max_radius)
plt.gca().set_aspect('equal', adjustable='box')
plt.axis('off')
plt.tight_layout()

output_file4 = os.path.join(output_dir, 'EGoD_network_layered_circular.png')
plt.savefig(output_file4, dpi=300, bbox_inches='tight')
print(f"Layered circular layout network graph saved: {output_file4}")
plt.close()

# Output network statistics
print("\n" + "="*50)
print("Network Statistics")
print("="*50)
print(f"Number of nodes: {G.number_of_nodes()}")
print(f"Number of edges: {G.number_of_edges()}")
print(f"Average degree: {sum(dict(G.degree()).values()) / G.number_of_nodes():.2f}")
print(f"Network density: {nx.density(G):.4f}")

# Count nodes by group
print("\nNodes per group:")
for group in unique_groups:
    count = len(nodes_by_group.get(group, []))
    print(f"{group}: {count}")

# Save statistics
stats_df = pd.DataFrame({
    'Metric': ['Total Nodes', 'Total Edges', 'Average Degree', 'Network Density'],
    'Value': [
        G.number_of_nodes(),
        G.number_of_edges(),
        sum(dict(G.degree()).values()) / G.number_of_nodes(),
        nx.density(G)
    ]
})

stats_file = os.path.join(output_dir, 'network_statistics.csv')
stats_df.to_csv(stats_file, index=False)
print(f"\nNetwork statistics saved: {stats_file}")

print("\n" + "="*50)
print("Network visualization completed!")
print("="*50)
print(f"All results saved to: {output_dir}")
