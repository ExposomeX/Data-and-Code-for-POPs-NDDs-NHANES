#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Calculate Path Diversity Score for Exposure-Protein-Protein-Disease (EPPD) Associations
Network Structure: 
  - PPI path: Exposure (E) -> Protein_1 (P1) -> Protein_2 (P2) -> Disease (D) [length=3]
"""

import os
import sys
import pandas as pd
import numpy as np
from collections import defaultdict
import matplotlib.pyplot as plt
import seaborn as sns
import warnings

# Set UTF-8 encoding for output
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# Set font
plt.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans', 'Liberation Sans']
plt.rcParams['axes.unicode_minus'] = False

# Ignore warnings
warnings.filterwarnings('ignore')

# Set working directory (using relative path)
base_dir = os.path.dirname(os.path.abspath(__file__))

# Auto-detect folder starting with 'ebio_summary_'
ebio_folders = [f for f in os.listdir(base_dir) if f.startswith('ebio_summary_') and os.path.isdir(os.path.join(base_dir, f))]
if not ebio_folders:
    raise FileNotFoundError("Folder starting with 'ebio_summary_' not found")
ebio_folder = ebio_folders[0]  # Use the first matching folder
print(f"Data folder found: {ebio_folder}")

data_dir = os.path.join(base_dir, ebio_folder, 'buildModel')
results_dir = os.path.join(base_dir, 'results', 'path_diversity_score_EPPD')

# Create results directory
os.makedirs(results_dir, exist_ok=True)

print("=" * 80)
print("EPPD Path Diversity Score Calculation")
print("(Exposure-Protein-Protein-Disease Network with PPI)")
print("=" * 80)

# Read node and edge data
print("\n1. Loading data...")
nodes_file = os.path.join(data_dir, 'EPPD_nodes_corrected.csv')
edges_file = os.path.join(data_dir, 'EPPD_edges_corrected.csv')

nodes_df = pd.read_csv(nodes_file)
edges_df = pd.read_csv(edges_file)

print(f"   Number of nodes: {len(nodes_df)}")
print(f"   Number of edges: {len(edges_df)}")

# Count nodes by type
exposure_nodes = nodes_df[nodes_df['EXID'].str.startswith('EX:E')]
protein_nodes = nodes_df[nodes_df['EXID'].str.startswith('EX:P')]
disease_nodes = nodes_df[nodes_df['EXID'].str.startswith('EX:D')]

print(f"\n   Exposure nodes: {len(exposure_nodes)}")
print(f"   Protein nodes: {len(protein_nodes)}")
print(f"   Disease nodes: {len(disease_nodes)}")

# Create node name mapping
node_names = dict(zip(nodes_df['EXID'], nodes_df['Preferred name']))

# 2. Build network structure
print("\n2. Building EPPD network structure...")

# Identify edge types based on Source and Target groups
# Edge type 1: Exposure -> Protein_1
exposure_protein1_edges = edges_df[
    (edges_df['Source'].str.startswith('EX:E')) & 
    (edges_df['Target'].str.startswith('EX:P')) &
    (edges_df['Target group'] == 'Protein_1')
]

# Edge type 2: Protein_1 -> Protein_2 (protein-protein interaction)
protein_protein_edges = edges_df[
    (edges_df['Source'].str.startswith('EX:P')) & 
    (edges_df['Target'].str.startswith('EX:P'))
]

# Edge type 3: Protein_2 -> Disease
protein_disease_edges = edges_df[
    (edges_df['Source'].str.startswith('EX:P')) & 
    (edges_df['Target'].str.startswith('EX:D'))
]

print(f"   Exposure->Protein_1 edges: {len(exposure_protein1_edges)}")
print(f"   Protein_1->Protein_2 edges (PPI): {len(protein_protein_edges)}")
print(f"   Protein_2->Disease edges: {len(protein_disease_edges)}")

# Build adjacency dictionaries
# exposure_to_protein1: {exposure_id: [protein1_id1, protein1_id2, ...]}
exposure_to_protein1 = defaultdict(list)
for _, row in exposure_protein1_edges.iterrows():
    exposure_to_protein1[row['Source']].append(row['Target'])

# protein1_to_protein2: {protein1_id: [protein2_id1, protein2_id2, ...]}
protein1_to_protein2 = defaultdict(list)
for _, row in protein_protein_edges.iterrows():
    protein1_to_protein2[row['Source']].append(row['Target'])

# protein2_to_diseases: {protein2_id: [disease_id1, disease_id2, ...]}
protein2_to_diseases = defaultdict(list)
for _, row in protein_disease_edges.iterrows():
    protein2_to_diseases[row['Source']].append(row['Target'])

# 3. Calculate Path Diversity Score
print("\n3. Calculating Path Diversity Scores for Exposure-Disease pairs...")
print("   Only considering PPI-mediated pathways (E->P1->P2->D)...")

# Store results
path_scores = []

# Iterate through all exposures
for exposure_id in exposure_to_protein1.keys():
    exposure_name = node_names.get(exposure_id, exposure_id)
    
    # Dictionary to store all paths to each disease
    # Structure: {disease_id: [(protein1_id, protein2_id), ...]}
    disease_paths = defaultdict(list)
    
    # Get all Protein_1 connected to this exposure
    protein1_list = exposure_to_protein1.get(exposure_id, [])
    
    # For each Protein_1, find Protein_2 through PPI
    for protein1_id in protein1_list:
        # Get Protein_2 that interact with Protein_1
        protein2_interactors = protein1_to_protein2.get(protein1_id, [])
        
        for protein2_id in protein2_interactors:
            # Check if Protein_2 connects to any disease
            connected_diseases = protein2_to_diseases.get(protein2_id, [])
            
            for disease_id in connected_diseases:
                # Record path: E -> P1 -> P2 -> D
                disease_paths[disease_id].append((protein1_id, protein2_id))
    
    # Calculate Path Diversity Score for each exposure-disease pair
    for disease_id, paths in disease_paths.items():
        disease_name = node_names.get(disease_id, disease_id)
        
        # Total number of paths
        num_ppi_paths = len(paths)
        
        # Collect all unique proteins (both P1 and P2)
        all_protein1 = [p[0] for p in paths]
        all_protein2 = [p[1] for p in paths]
        all_proteins = all_protein1 + all_protein2
        
        # Remove duplicates while preserving order
        unique_proteins = list(dict.fromkeys(all_proteins))
        unique_protein1 = list(dict.fromkeys(all_protein1))
        unique_protein2 = list(dict.fromkeys(all_protein2))
        
        # Get degree for each unique protein
        protein_degrees = []
        for protein_id in unique_proteins:
            degree = nodes_df[nodes_df['EXID'] == protein_id]['Degree'].values
            if len(degree) > 0:
                protein_degrees.append(degree[0])
            else:
                protein_degrees.append(1)  # Default value
        
        # Calculate scores
        pds_simple = num_ppi_paths
        pds_weighted = sum(protein_degrees)
        pds_normalized = pds_weighted / len(unique_proteins) if len(unique_proteins) > 0 else 0
        
        # Path length is always 3 for E->P1->P2->D
        path_length = 3
        
        path_scores.append({
            'Exposure_ID': exposure_id,
            'Exposure_Name': exposure_name,
            'Disease_ID': disease_id,
            'Disease_Name': disease_name,
            'Num_Paths_PPI': num_ppi_paths,
            'Num_Unique_Proteins': len(unique_proteins),
            'Num_Unique_Protein1': len(unique_protein1),
            'Num_Unique_Protein2': len(unique_protein2),
            'Path_Length': path_length,
            'PDS_Simple': pds_simple,
            'PDS_Weighted': pds_weighted,
            'PDS_Normalized': pds_normalized,
            'Mediating_Protein1': '|'.join(unique_protein1),
            'Mediating_Protein2': '|'.join(unique_protein2),
            'Protein1_Names': '|'.join([node_names.get(p, p) for p in unique_protein1]),
            'Protein2_Names': '|'.join([node_names.get(p, p) for p in unique_protein2])
        })

# Convert to DataFrame
results_df = pd.DataFrame(path_scores)

print(f"   Calculated {len(results_df)} exposure-disease pairs")

# 4. Statistical analysis
print("\n4. Statistical analysis...")
print(f"\n   PPI path statistics:")
print(f"   - Min paths: {results_df['Num_Paths_PPI'].min()}")
print(f"   - Max paths: {results_df['Num_Paths_PPI'].max()}")
print(f"   - Mean paths: {results_df['Num_Paths_PPI'].mean():.2f}")
print(f"   - Median paths: {results_df['Num_Paths_PPI'].median():.2f}")

print(f"\n   Protein statistics:")
print(f"   - Mean unique proteins (total): {results_df['Num_Unique_Proteins'].mean():.2f}")
print(f"   - Mean unique Protein_1: {results_df['Num_Unique_Protein1'].mean():.2f}")
print(f"   - Mean unique Protein_2: {results_df['Num_Unique_Protein2'].mean():.2f}")

print(f"\n   PDS_Weighted statistics:")
print(f"   - Range: {results_df['PDS_Weighted'].min():.2f} - {results_df['PDS_Weighted'].max():.2f}")
print(f"   - Mean: {results_df['PDS_Weighted'].mean():.2f}")

# 5. Save results
print("\n5. Saving results...")

# Sort by PDS_Weighted in descending order
results_sorted = results_df.sort_values('PDS_Weighted', ascending=False)

# Save complete results
output_file = os.path.join(results_dir, 'exposure_disease_path_diversity_scores_EPPD.csv')
results_sorted.to_csv(output_file, index=False, encoding='utf-8-sig')
print(f"   Complete results saved: {output_file}")

# Save Top 50 results
top50_file = os.path.join(results_dir, 'exposure_disease_top50_scores_EPPD.csv')
results_sorted.head(50).to_csv(top50_file, index=False, encoding='utf-8-sig')
print(f"   Top 50 results saved: {top50_file}")

# 6. Display Top 20 results
print("\n6. Top 20 Exposure-Disease pairs (sorted by PDS_Weighted):")
print("=" * 130)
print(f"{'Rank':<6}{'Exposure':<25}{'Disease':<25}{'PPI_Paths':<10}{'Protein1':<10}{'Protein2':<10}{'PDS_W':<10}")
print("=" * 130)

for idx, row in results_sorted.head(20).iterrows():
    rank = results_sorted.index.get_loc(idx) + 1
    print(f"{rank:<6}{str(row['Exposure_Name'])[:23]:<25}{str(row['Disease_Name'])[:23]:<25}"
          f"{row['Num_Paths_PPI']:<10}{row['Num_Unique_Protein1']:<10}{row['Num_Unique_Protein2']:<10}"
          f"{row['PDS_Weighted']:<10.2f}")

# 7. Visualization
print("\n7. Generating visualization plots...")

fig, axes = plt.subplots(2, 3, figsize=(20, 12))

# Plot 1: PPI path count distribution
ax1 = axes[0, 0]
ax1.hist(results_df['Num_Paths_PPI'], bins=30, color='skyblue', edgecolor='black', alpha=0.7)
ax1.set_xlabel('Number of PPI Paths', fontsize=12)
ax1.set_ylabel('Frequency', fontsize=12)
ax1.set_title('Distribution of PPI Path Counts', fontsize=14, fontweight='bold')
ax1.grid(axis='y', alpha=0.3)

# Plot 2: Protein count comparison
ax2 = axes[0, 1]
protein_types = ['Protein_1', 'Protein_2', 'Total']
protein_means = [
    results_df['Num_Unique_Protein1'].mean(),
    results_df['Num_Unique_Protein2'].mean(),
    results_df['Num_Unique_Proteins'].mean()
]
ax2.bar(protein_types, protein_means, color=['steelblue', 'lightcoral', 'mediumseagreen'], alpha=0.8)
ax2.set_ylabel('Average Number of Unique Proteins', fontsize=12)
ax2.set_title('Average Unique Proteins by Type', fontsize=14, fontweight='bold')
ax2.grid(axis='y', alpha=0.3)

# Plot 3: PDS_Weighted distribution
ax3 = axes[0, 2]
ax3.hist(results_df['PDS_Weighted'], bins=30, color='lightcoral', edgecolor='black', alpha=0.7)
ax3.set_xlabel('PDS Weighted Score', fontsize=12)
ax3.set_ylabel('Frequency', fontsize=12)
ax3.set_title('Distribution of PDS Weighted Scores', fontsize=14, fontweight='bold')
ax3.grid(axis='y', alpha=0.3)

# Plot 4: Top 15 Exposure-Disease pairs
ax4 = axes[1, 0]
top15 = results_sorted.head(15)
y_pos = np.arange(len(top15))
labels = [f"{str(row['Exposure_Name'])[:12]}→{str(row['Disease_Name'])[:12]}" 
          for _, row in top15.iterrows()]
ax4.barh(y_pos, top15['PDS_Weighted'], color='mediumseagreen', alpha=0.8)
ax4.set_yticks(y_pos)
ax4.set_yticklabels(labels, fontsize=9)
ax4.set_xlabel('PDS Weighted Score', fontsize=12)
ax4.set_title('Top 15 Exposure-Disease Pairs', fontsize=14, fontweight='bold')
ax4.invert_yaxis()
ax4.grid(axis='x', alpha=0.3)

# Plot 5: Path count vs PDS_Weighted scatter plot
ax5 = axes[1, 1]
scatter = ax5.scatter(results_df['Num_Paths_PPI'], results_df['PDS_Weighted'], 
                     c=results_df['Num_Unique_Proteins'], cmap='viridis', 
                     alpha=0.6, s=50, edgecolors='black', linewidth=0.5)
ax5.set_xlabel('Number of PPI Paths', fontsize=12)
ax5.set_ylabel('PDS Weighted Score', fontsize=12)
ax5.set_title('PPI Path Count vs PDS Weighted', fontsize=14, fontweight='bold')
ax5.grid(alpha=0.3)
cbar = plt.colorbar(scatter, ax=ax5)
cbar.set_label('Unique Proteins', fontsize=10)

# Plot 6: Protein1 vs Protein2 count
ax6 = axes[1, 2]
ax6.scatter(results_df['Num_Unique_Protein1'], results_df['Num_Unique_Protein2'], 
           alpha=0.5, s=30, color='mediumpurple', edgecolors='black', linewidth=0.5)
ax6.set_xlabel('Number of Unique Protein_1', fontsize=12)
ax6.set_ylabel('Number of Unique Protein_2', fontsize=12)
ax6.set_title('Protein_1 vs Protein_2 Distribution', fontsize=14, fontweight='bold')
ax6.grid(alpha=0.3)

plt.tight_layout()
plot_file = os.path.join(results_dir, 'path_diversity_score_analysis_EPPD.png')
plt.savefig(plot_file, dpi=300, bbox_inches='tight')
print(f"   Visualization plots saved: {plot_file}")

# 8. Generate summary statistics by exposure and disease
print("\n8. Generating summary statistics for exposures and diseases...")

# Aggregate by exposure
exposure_summary = results_df.groupby(['Exposure_ID', 'Exposure_Name']).agg({
    'Disease_ID': 'count',
    'Num_Paths_PPI': 'sum',
    'PDS_Weighted': 'sum'
}).rename(columns={
    'Disease_ID': 'Num_Diseases',
    'Num_Paths_PPI': 'Total_PPI_Paths',
    'PDS_Weighted': 'Total_PDS_Weighted'
}).reset_index()

exposure_summary = exposure_summary.sort_values('Total_PDS_Weighted', ascending=False)
exposure_summary_file = os.path.join(results_dir, 'exposure_summary_scores_EPPD.csv')
exposure_summary.to_csv(exposure_summary_file, index=False, encoding='utf-8-sig')
print(f"   Exposure summary saved: {exposure_summary_file}")

# Aggregate by disease
disease_summary = results_df.groupby(['Disease_ID', 'Disease_Name']).agg({
    'Exposure_ID': 'count',
    'Num_Paths_PPI': 'sum',
    'PDS_Weighted': 'sum'
}).rename(columns={
    'Exposure_ID': 'Num_Exposures',
    'Num_Paths_PPI': 'Total_PPI_Paths',
    'PDS_Weighted': 'Total_PDS_Weighted'
}).reset_index()

disease_summary = disease_summary.sort_values('Total_PDS_Weighted', ascending=False)
disease_summary_file = os.path.join(results_dir, 'disease_summary_scores_EPPD.csv')
disease_summary.to_csv(disease_summary_file, index=False, encoding='utf-8-sig')
print(f"   Disease summary saved: {disease_summary_file}")

# Display Top 10 exposures
print("\n   Top 10 Exposures (by Total_PDS_Weighted):")
print("   " + "-" * 90)
for idx, row in exposure_summary.head(10).iterrows():
    print(f"   {str(row['Exposure_Name'])[:35]:<37} | Diseases: {row['Num_Diseases']:<3} | "
          f"PPI Paths: {row['Total_PPI_Paths']:<5} | Score: {row['Total_PDS_Weighted']:.2f}")

# Display Top 10 diseases
print("\n   Top 10 Diseases (by Total_PDS_Weighted):")
print("   " + "-" * 90)
for idx, row in disease_summary.head(10).iterrows():
    print(f"   {str(row['Disease_Name'])[:35]:<37} | Exposures: {row['Num_Exposures']:<3} | "
          f"PPI Paths: {row['Total_PPI_Paths']:<5} | Score: {row['Total_PDS_Weighted']:.2f}")

print("\n" + "=" * 80)
print("Calculation completed!")
print("=" * 80)
print("\nOutput files:")
print(f"  1. {output_file}")
print(f"  2. {top50_file}")
print(f"  3. {exposure_summary_file}")
print(f"  4. {disease_summary_file}")
print(f"  5. {plot_file}")
print("\nScore descriptions:")
print("  - Num_Paths_PPI: Number of E->P1->P2->D pathways (with protein-protein interaction)")
print("  - Num_Unique_Protein1: Number of unique Protein_1 in pathways")
print("  - Num_Unique_Protein2: Number of unique Protein_2 in pathways")
print("  - PDS_Weighted: Weighted score (sum of protein degrees)")
print("  - PDS_Normalized: Normalized score (PDS_Weighted / Num_Unique_Proteins)")
print("  - Path_Length: Fixed at 3 (E->P1->P2->D)")
print("=" * 80)
