#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
EGoD Network Visualization Script
Read edges and nodes files, draw network graph
Node size proportional to degree
"""

import os
import sys
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
import networkx as nx
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

# Set UTF-8 encoding for output
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# Set English font
plt.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans', 'Liberation Sans']
plt.rcParams['axes.unicode_minus'] = False

# Ignore warnings
warnings.filterwarnings('ignore')

# Auto-detect folders starting with ebio_summary_
current_dir = os.getcwd()
ebio_folders = [f for f in os.listdir(current_dir) 
                if os.path.isdir(os.path.join(current_dir, f)) and f.startswith('ebio_summary_')]

if not ebio_folders:
    print("Error: Folder starting with 'ebio_summary_' not found")
    sys.exit(1)

# Use the first ebio_summary_ folder found
ebio_folder = ebio_folders[0]
print(f"Folder found: {ebio_folder}")

# File paths
base_dir = os.path.join(ebio_folder, 'buildModel')
if not os.path.exists(base_dir):
    print(f"Error: buildModel folder does not exist in {ebio_folder}")
    sys.exit(1)
edges_file = os.path.join(base_dir, 'EGoD_edges_corrected.csv')
nodes_file = os.path.join(base_dir, 'EGoD_nodes_corrected.csv')
output_dir = os.path.join("results_viz_ebio", 'viz_EGoD/set_node_size_vs_degree')

# Create output directory
os.makedirs(output_dir, exist_ok=True)

print("="*50)
print("EGoD Network Visualization (Node Size vs Degree)")
print("="*50)

# Read data
print("\nReading edge data...")
edges_df = pd.read_csv(edges_file)
print(f"Edge data shape: {edges_df.shape}")
print(f"Edge data columns: {edges_df.columns.tolist()}")
print(f"Number of edges: {len(edges_df)}")

print("\nReading node data...")
nodes_df = pd.read_csv(nodes_file)
print(f"Node data shape: {nodes_df.shape}")
print(f"Node data columns: {nodes_df.columns.tolist()}")
print(f"Number of nodes: {len(nodes_df)}")

# Check required columns
if 'Source' not in edges_df.columns or 'Target' not in edges_df.columns:
    print("Error: edges file missing Source or Target column")
    sys.exit(1)

if 'Group name' not in nodes_df.columns:
    print("Error: nodes file missing Group name column")
    sys.exit(1)

# Get node ID column name (usually first column or 'Id')
node_id_col = nodes_df.columns[0] if 'Id' not in nodes_df.columns else 'Id'
print(f"\nUsing node ID column: {node_id_col}")

# Create network graph
print("\nCreating network graph...")
G = nx.Graph()

# Add edges
for _, row in edges_df.iterrows():
    G.add_edge(row['Source'], row['Target'])

print(f"Network nodes: {G.number_of_nodes()}")
print(f"Network edges: {G.number_of_edges()}")

# Create node to group, name and degree mapping
node_to_group = {}
node_to_name = {}
node_to_degree = {}
for _, row in nodes_df.iterrows():
    node_id = row[node_id_col]
    group = row['Group name']
    preferred_name = row['Preferred name'] if pd.notna(row['Preferred name']) else str(node_id)
    degree = row['Degree'] if 'Degree' in nodes_df.columns and pd.notna(row['Degree']) else 1
    node_to_group[node_id] = group
    node_to_name[node_id] = preferred_name
    node_to_degree[node_id] = degree

# Calculate node size (based on Degree, scaled to appropriate display range)
min_degree = min(node_to_degree.values())
max_degree = max(node_to_degree.values())
print(f"\nNode degree range: {min_degree} - {max_degree}")

# Node size scaling parameters
size_scale = 50  # Base size
size_multiplier = 20  # Degree multiplier

node_sizes = {}
for node in G.nodes():
    degree = node_to_degree.get(node, 1)
    node_sizes[node] = size_scale + degree * size_multiplier

# Get all unique groups
unique_groups = nodes_df['Group name'].unique()
print(f"\nNumber of groups: {len(unique_groups)}")
print(f"Group list: {unique_groups.tolist()}")

# Assign fixed colors for each group: Exposure=blue, GO=green, Disease=red
group_to_color = {
    'Exposure': (0.2, 0.4, 0.8, 0.8),   # Blue (RGBA)
    'GO': (0.2, 0.7, 0.3, 0.8),         # Green (RGBA)
    'Disease': (0.9, 0.2, 0.2, 0.8)     # Red (RGBA)
}

# Assign colors to nodes
node_colors = []
for node in G.nodes():
    group = node_to_group.get(node, 'Unknown')
    node_colors.append(group_to_color.get(group, (0.5, 0.5, 0.5)))

# Get node size list (in G.nodes() order)
node_size_list = [node_sizes[node] for node in G.nodes()]

# Helper function to create size legend
def add_size_legend(ax, min_deg, max_deg, size_scale, size_mult):
    """Add node size legend, using log2 scaling for smoother circle sizes"""
    # Select representative degree values
    legend_degrees = [min_deg, (min_deg + max_deg) // 2, max_deg]
    legend_sizes = [size_scale + d * size_mult for d in legend_degrees]
    
    # Add size legend in bottom right - use figure coordinates to ensure perfect circles
    fig = ax.get_figure()
    legend_x = 0.85
    legend_y = 0.05
    spacing = 0.04  # Reduce spacing between circles
    
    for i, (deg, size) in enumerate(zip(legend_degrees, legend_sizes)):
        # Use log2 scaling for circle size to make it smoother
        circle_radius = np.log2(size + 1) / 1000  # log2 scaling
        
        # Draw perfect circle - use figure coordinate system to ensure 1:1 aspect ratio
        circle = plt.Circle((legend_x, legend_y + i * spacing), 
                           circle_radius,
                           color='gray', alpha=0.5, 
                           transform=fig.transFigure,  # Use figure coordinates
                           clip_on=False)
        fig.add_artist(circle)  # Add to figure instead of axes
        
        # Add text label
        fig.text(legend_x + 0.05, legend_y + i * spacing, 
                f'Degree = {deg}',
                fontsize=10, 
                va='center')
    
    # Add title
    fig.text(legend_x, legend_y + len(legend_degrees) * spacing + 0.02,
            'Node Size',
            fontsize=11,
            fontweight='bold',
            va='bottom')

# Draw network graph
print("\nDrawing network graph...")

# Figure 1: Using spring layout
fig, ax = plt.subplots(figsize=(20, 16))
pos = nx.spring_layout(G, k=2, iterations=50, seed=42)

nx.draw_networkx_nodes(G, pos, 
                       node_color=node_colors,
                       node_size=node_size_list,
                       alpha=0.8,
                       ax=ax)

nx.draw_networkx_edges(G, pos, 
                       alpha=0.025,
                       width=1,
                       ax=ax)

# Use preferred name as label
labels = {node: node_to_name.get(node, str(node)) for node in G.nodes()}
nx.draw_networkx_labels(G, pos, 
                        labels=labels,
                        font_size=8,
                        font_color='grey',
                        alpha=0.5,
                        ax=ax)

# Add legend (fixed order: Exposure, GO, Disease) - using circular markers
legend_groups = ['Exposure', 'GO', 'Disease']
legend_elements = [Line2D([0], [0], marker='o', color='w', 
                         markerfacecolor=group_to_color[group][:3],
                         markersize=10, label=group, alpha=0.8) 
                  for group in legend_groups if group in group_to_color]
ax.legend(handles=legend_elements, 
          loc='upper left', 
          fontsize=10,
          title='Group Name')

# Add node size legend
add_size_legend(ax, min_degree, max_degree, size_scale, size_multiplier)

ax.set_title('EGoD Network Visualization (Spring Layout)\nNode size proportional to Degree', 
             fontsize=16, pad=20)
ax.axis('off')
plt.tight_layout()

output_file1 = os.path.join(output_dir, 'EGoD_network_spring.png')
plt.savefig(output_file1, dpi=300, bbox_inches='tight')
print(f"Spring layout network graph saved: {output_file1}")
plt.close()

# Figure 2: Using kamada_kawai layout
fig2, ax2 = plt.subplots(figsize=(20, 16))
try:
    pos = nx.kamada_kawai_layout(G)
    
    nx.draw_networkx_nodes(G, pos, 
                           node_color=node_colors,
                           node_size=node_size_list,
                           alpha=0.8,
                           ax=ax2)
    
    nx.draw_networkx_edges(G, pos, 
                           alpha=0.025,
                           width=1,
                           ax=ax2)
    
    # Use preferred name as label
    nx.draw_networkx_labels(G, pos, 
                            labels=labels,
                            font_size=8,
                            font_color='grey',
                            alpha=0.5,
                            ax=ax2)
    
    # Add legend
    ax2.legend(handles=legend_elements, 
              loc='upper left', 
              fontsize=10,
              title='Group Name')
    
    # Add node size legend
    add_size_legend(ax2, min_degree, max_degree, size_scale, size_multiplier)
    
    ax2.set_title('EGoD Network Visualization (Kamada-Kawai Layout)\nNode size proportional to Degree', 
                  fontsize=16, pad=20)
    ax2.axis('off')
    plt.tight_layout()
    
    output_file2 = os.path.join(output_dir, 'EGoD_network_kamada_kawai.png')
    plt.savefig(output_file2, dpi=300, bbox_inches='tight')
    print(f"Kamada-Kawai layout network graph saved: {output_file2}")
    plt.close()
except:
    print("Kamada-Kawai layout failed, skipping")

# Figure 3: Using circular layout (by group)
fig3, ax3 = plt.subplots(figsize=(20, 16))

# Sort nodes by group
nodes_by_group = {}
for node in G.nodes():
    group = node_to_group.get(node, 'Unknown')
    if group not in nodes_by_group:
        nodes_by_group[group] = []
    nodes_by_group[group].append(node)

# Create circular layout by group
pos = {}
angle_step = 2 * np.pi / len(G.nodes())
current_angle = 0

for group in unique_groups:
    if group in nodes_by_group:
        for node in nodes_by_group[group]:
            pos[node] = (np.cos(current_angle), np.sin(current_angle))
            current_angle += angle_step

nx.draw_networkx_nodes(G, pos, 
                       node_color=node_colors,
                       node_size=node_size_list,
                       alpha=0.8,
                       ax=ax3)

nx.draw_networkx_edges(G, pos, 
                       alpha=0.025,
                       width=1,
                       ax=ax3)

# Use preferred name as label
nx.draw_networkx_labels(G, pos, 
                        labels=labels,
                        font_size=8,
                        font_color='grey',
                        alpha=0.5,
                        ax=ax3)

# Add legend
ax3.legend(handles=legend_elements, 
          loc='upper left', 
          fontsize=10,
          title='Group Name')

# Add node size legend
add_size_legend(ax3, min_degree, max_degree, size_scale, size_multiplier)

ax3.set_title('EGoD Network Visualization (Circular Layout)\nNode size proportional to Degree', 
              fontsize=16, pad=20)
ax3.axis('off')
plt.tight_layout()

output_file3 = os.path.join(output_dir, 'EGoD_network_circular.png')
plt.savefig(output_file3, dpi=300, bbox_inches='tight')
print(f"Circular layout network graph saved: {output_file3}")
plt.close()

# Figure 4: Using layered circular layout (Outer: Exposure, Middle: GO, Inner: Disease)
fig4, ax4 = plt.subplots(figsize=(20, 16))

# Assign to different circular layers by group
exposure_nodes = nodes_by_group.get('Exposure', [])
GO_nodes = nodes_by_group.get('GO', [])
disease_nodes = nodes_by_group.get('Disease', [])

pos = {}

# Outermost layer: Exposure (compounds) - radius 3
if exposure_nodes:
    n_exposure = len(exposure_nodes)
    for i, node in enumerate(exposure_nodes):
        angle = 2 * np.pi * i / n_exposure
        pos[node] = (3 * np.cos(angle), 3 * np.sin(angle))

# Middle layer: GO (gene ontology) - radius 2
if GO_nodes:
    n_GO = len(GO_nodes)
    for i, node in enumerate(GO_nodes):
        angle = 2 * np.pi * i / n_GO
        pos[node] = (2 * np.cos(angle), 2 * np.sin(angle))

# Innermost layer: Disease - ALL diseases at center (0, 0)
if disease_nodes:
    print(f"\n=== Disease Nodes Debug ===")
    print(f"Total disease nodes: {len(disease_nodes)}")
    for node in disease_nodes:
        node_name = node_to_name.get(node, str(node))
        print(f"  Disease node: {node_name} (ID: {node})")
    
    # Place ALL disease nodes at exact center (0, 0)
    for node in disease_nodes:
        pos[node] = (0.0, 0.0)
        print(f"  -> Placed at center (0, 0): {node_to_name.get(node, node)}")
    print(f"=========================\n")

nx.draw_networkx_nodes(G, pos, 
                       node_color=node_colors,
                       node_size=node_size_list,
                       alpha=0.8,
                       ax=ax4)

nx.draw_networkx_edges(G, pos, 
                       alpha=0.025,
                       width=1,
                       ax=ax4)

# Use preferred name as label
nx.draw_networkx_labels(G, pos, 
                        labels=labels,
                        font_size=8,
                        font_color='grey',
                        alpha=0.5,
                        ax=ax4)

# Add legend
ax4.legend(handles=legend_elements, 
          loc='upper left', 
          fontsize=10,
          title='Group Name')

# Add node size legend
add_size_legend(ax4, min_degree, max_degree, size_scale, size_multiplier)

# Add circular guide lines
circle0 = plt.Circle((0, 0), 0.5, color='gray', fill=False, linestyle='--', linewidth=1, alpha=0.025)
circle1 = plt.Circle((0, 0), 1, color='gray', fill=False, linestyle='--', linewidth=1, alpha=0.025)
circle2 = plt.Circle((0, 0), 2, color='gray', fill=False, linestyle='--', linewidth=1, alpha=0.025)
circle3 = plt.Circle((0, 0), 3, color='gray', fill=False, linestyle='--', linewidth=1, alpha=0.025)
ax4.add_patch(circle0)
ax4.add_patch(circle1)
ax4.add_patch(circle2)
ax4.add_patch(circle3)

# Add layer annotations
ax4.text(0, 3.3, 'Exposure (Outer)', ha='center', fontsize=12, fontweight='bold')
ax4.text(0, 2.3, 'GO (Middle)', ha='center', fontsize=12, fontweight='bold')
ax4.text(0, 1.3, 'Disease (Inner)', ha='center', fontsize=12, fontweight='bold')
ax4.text(0, 0.7, 'EX:D (Center)', ha='center', fontsize=10, fontweight='bold', color='darkred')

ax4.set_title('EGoD Network Visualization (Layered Circular Layout)\nOuter: Exposure, Middle: GO, Inner: Disease\nNode size proportional to Degree', 
              fontsize=16, pad=20)

# Force symmetric axis limits to center the plot at (0,0)
max_radius = 3.5  # Slightly larger than outermost layer
ax4.set_xlim(-max_radius, max_radius)
ax4.set_ylim(-max_radius, max_radius)
ax4.set_aspect('equal', adjustable='box')
ax4.axis('off')
plt.tight_layout()

output_file4 = os.path.join(output_dir, 'EGoD_network_layered_circular.png')
plt.savefig(output_file4, dpi=300, bbox_inches='tight')
print(f"Layered circular layout network graph saved: {output_file4}")
plt.close()

# Output network statistics
print("\n" + "="*50)
print("Network Statistics")
print("="*50)
print(f"Number of nodes: {G.number_of_nodes()}")
print(f"Number of edges: {G.number_of_edges()}")
print(f"Average degree: {sum(dict(G.degree()).values()) / G.number_of_nodes():.2f}")
print(f"Network density: {nx.density(G):.4f}")

# Count nodes by group
print("\nNodes per group:")
for group in unique_groups:
    count = len(nodes_by_group.get(group, []))
    print(f"{group}: {count}")

# Save statistics
stats_df = pd.DataFrame({
    'Metric': ['Total Nodes', 'Total Edges', 'Average Degree', 'Network Density'],
    'Value': [
        G.number_of_nodes(),
        G.number_of_edges(),
        sum(dict(G.degree()).values()) / G.number_of_nodes(),
        nx.density(G)
    ]
})

stats_file = os.path.join(output_dir, 'network_statistics.csv')
stats_df.to_csv(stats_file, index=False)
print(f"\nNetwork statistics saved: {stats_file}")

print("\n" + "="*50)
print("Network visualization completed!")
print("="*50)
print(f"All results saved to: {output_dir}")
