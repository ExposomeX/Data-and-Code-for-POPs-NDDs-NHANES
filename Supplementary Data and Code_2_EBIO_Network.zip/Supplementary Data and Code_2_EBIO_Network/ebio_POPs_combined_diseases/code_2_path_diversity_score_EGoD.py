#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Calculate Path Diversity Score for Exposure-Disease Associations
Network Structure: Exposure (E) -> GO -> Disease (D)
Fixed path length = 2
"""

import os
import sys
import pandas as pd
import numpy as np
from collections import defaultdict
import matplotlib.pyplot as plt
import seaborn as sns
import warnings

# Set UTF-8 encoding for output
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# Set font
plt.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans', 'Liberation Sans']
plt.rcParams['axes.unicode_minus'] = False

# Ignore warnings
warnings.filterwarnings('ignore')

# Set working directory (using relative path)
base_dir = os.path.dirname(os.path.abspath(__file__))

# Auto-detect folder starting with 'ebio_summary_'
ebio_folders = [f for f in os.listdir(base_dir) if f.startswith('ebio_summary_') and os.path.isdir(os.path.join(base_dir, f))]
if not ebio_folders:
    raise FileNotFoundError("Folder starting with 'ebio_summary_' not found")
ebio_folder = ebio_folders[0]  # Use the first matching folder
print(f"Data folder found: {ebio_folder}")

data_dir = os.path.join(base_dir, ebio_folder, 'buildModel')
results_dir = os.path.join(base_dir, 'results', 'path_diversity_score_EGoD')

# Create results directory
os.makedirs(results_dir, exist_ok=True)

print("=" * 80)
print("Path Diversity Score Calculation for Exposure-Disease Associations")
print("=" * 80)

# Read node and edge data
print("\n1. Loading data...")
nodes_file = os.path.join(data_dir, 'EGoD_nodes_corrected.csv')
edges_file = os.path.join(data_dir, 'EGoD_edges_corrected.csv')

nodes_df = pd.read_csv(nodes_file)
edges_df = pd.read_csv(edges_file)

print(f"   Number of nodes: {len(nodes_df)}")
print(f"   Number of edges: {len(edges_df)}")

# Count nodes by type
exposure_nodes = nodes_df[nodes_df['EXID'].str.startswith('EX:E')]
go_nodes = nodes_df[nodes_df['EXID'].str.startswith('GO:')]
disease_nodes = nodes_df[nodes_df['EXID'].str.startswith('EX:D')]

print(f"\n   Exposure nodes: {len(exposure_nodes)}")
print(f"   GO nodes: {len(go_nodes)}")
print(f"   Disease nodes: {len(disease_nodes)}")

# Create node name mapping
node_names = dict(zip(nodes_df['EXID'], nodes_df['Preferred name']))

# 2. Build network structure
print("\n2. Building network structure...")

# Exposure -> GO edges (Edge type = 1)
exposure_go_edges = edges_df[
    (edges_df['Source'].str.startswith('EX:E')) & 
    (edges_df['Target'].str.startswith('GO:'))
]

# GO -> Disease edges (Edge type = 2)
go_disease_edges = edges_df[
    (edges_df['Source'].str.startswith('GO:')) & 
    (edges_df['Target'].str.startswith('EX:D'))
]

print(f"   Exposure->GO edges: {len(exposure_go_edges)}")
print(f"   GO->Disease edges: {len(go_disease_edges)}")

# Build adjacency dictionaries
# exposure_to_gos: {exposure_id: [go_id1, go_id2, ...]}
exposure_to_gos = defaultdict(list)
for _, row in exposure_go_edges.iterrows():
    exposure_to_gos[row['Source']].append(row['Target'])

# go_to_diseases: {go_id: [disease_id1, disease_id2, ...]}
go_to_diseases = defaultdict(list)
for _, row in go_disease_edges.iterrows():
    go_to_diseases[row['Source']].append(row['Target'])

# 3. Calculate Path Diversity Score
print("\n3. Calculating Path Diversity Scores for Exposure-Disease pairs...")

# Store results
path_scores = []

# Iterate through all exposures
for exposure_id in exposure_to_gos.keys():
    exposure_name = node_names.get(exposure_id, exposure_id)
    
    # Get all GO terms connected to this exposure
    connected_gos = exposure_to_gos[exposure_id]
    
    # Find all reachable diseases through these GO terms
    # Use dictionary to record paths for each disease
    disease_paths = defaultdict(list)
    
    for go_id in connected_gos:
        go_name = node_names.get(go_id, go_id)
        
        # Get all diseases connected to this GO term
        connected_diseases = go_to_diseases.get(go_id, [])
        
        for disease_id in connected_diseases:
            # Record path: exposure -> GO -> disease
            disease_paths[disease_id].append(go_id)
    
    # Calculate Path Diversity Score for each exposure-disease pair
    for disease_id, proteins_in_paths in disease_paths.items():
        disease_name = node_names.get(disease_id, disease_id)
        
        # Number of paths
        num_paths = len(proteins_in_paths)
        
        # Path Diversity Score (PDS)
        # Method 1: Simple count - number of paths
        pds_simple = num_paths
        
        # Method 2: Weighted by GO importance - using GO degree
        # Get degree for each mediating GO term
        go_degrees = []
        for go_id in proteins_in_paths:
            degree = nodes_df[nodes_df['EXID'] == go_id]['Degree'].values
            if len(degree) > 0:
                go_degrees.append(degree[0])
            else:
                go_degrees.append(1)  # Default value
        
        # Weighted score: considering GO importance
        pds_weighted = sum(go_degrees)
        
        # Normalized weighted score
        pds_normalized = sum(go_degrees) / num_paths if num_paths > 0 else 0
        
        path_scores.append({
            'Exposure_ID': exposure_id,
            'Exposure_Name': exposure_name,
            'Disease_ID': disease_id,
            'Disease_Name': disease_name,
            'Num_Paths': num_paths,
            'PDS_Simple': pds_simple,
            'PDS_Weighted': pds_weighted,
            'PDS_Normalized': pds_normalized,
            'Mediating_GOs': '|'.join(proteins_in_paths),
            'GO_Names': '|'.join([str(node_names.get(p, p)) if pd.notna(node_names.get(p, p)) else p for p in proteins_in_paths])
        })

# Convert to DataFrame
results_df = pd.DataFrame(path_scores)

print(f"   Calculated {len(results_df)} exposure-disease pairs")

# 4. Statistical analysis
print("\n4. Statistical analysis...")
print(f"\n   Path count statistics:")
print(f"   - Min paths: {results_df['Num_Paths'].min()}")
print(f"   - Max paths: {results_df['Num_Paths'].max()}")
print(f"   - Mean paths: {results_df['Num_Paths'].mean():.2f}")
print(f"   - Median paths: {results_df['Num_Paths'].median():.2f}")

print(f"\n   PDS_Simple statistics:")
print(f"   - Range: {results_df['PDS_Simple'].min()} - {results_df['PDS_Simple'].max()}")
print(f"   - Mean: {results_df['PDS_Simple'].mean():.2f}")

print(f"\n   PDS_Weighted statistics:")
print(f"   - Range: {results_df['PDS_Weighted'].min():.2f} - {results_df['PDS_Weighted'].max():.2f}")
print(f"   - Mean: {results_df['PDS_Weighted'].mean():.2f}")

# 5. Save results
print("\n5. Saving results...")

# Sort by PDS_Weighted in descending order
results_sorted = results_df.sort_values('PDS_Weighted', ascending=False)

# Save complete results
output_file = os.path.join(results_dir, 'exposure_disease_path_diversity_scores.csv')
results_sorted.to_csv(output_file, index=False, encoding='utf-8-sig')
print(f"   Complete results saved: {output_file}")

# Save Top 50 results
top50_file = os.path.join(results_dir, 'exposure_disease_top50_scores.csv')
results_sorted.head(50).to_csv(top50_file, index=False, encoding='utf-8-sig')
print(f"   Top 50 results saved: {top50_file}")

# 6. Display Top 20 results
print("\n6. Top 20 Exposure-Disease pairs (sorted by PDS_Weighted):")
print("=" * 120)
print(f"{'Rank':<6}{'Exposure':<30}{'Disease':<30}{'Paths':<10}{'PDS_Weighted':<15}")
print("=" * 120)

for idx, row in results_sorted.head(20).iterrows():
    rank = results_sorted.index.get_loc(idx) + 1
    print(f"{rank:<6}{row['Exposure_Name'][:28]:<30}{row['Disease_Name'][:28]:<30}"
          f"{row['Num_Paths']:<10}{row['PDS_Weighted']:<15.2f}")

# 7. Visualization
print("\n7. Generating visualization plots...")

fig, axes = plt.subplots(2, 2, figsize=(16, 12))

# Plot 1: Path count distribution
ax1 = axes[0, 0]
ax1.hist(results_df['Num_Paths'], bins=30, color='skyblue', edgecolor='black', alpha=0.7)
ax1.set_xlabel('Number of Paths', fontsize=12)
ax1.set_ylabel('Frequency', fontsize=12)
ax1.set_title('Distribution of Path Counts (Exposure-Disease)', fontsize=14, fontweight='bold')
ax1.grid(axis='y', alpha=0.3)

# Plot 2: PDS_Weighted distribution
ax2 = axes[0, 1]
ax2.hist(results_df['PDS_Weighted'], bins=30, color='lightcoral', edgecolor='black', alpha=0.7)
ax2.set_xlabel('PDS Weighted Score', fontsize=12)
ax2.set_ylabel('Frequency', fontsize=12)
ax2.set_title('Distribution of PDS Weighted Scores', fontsize=14, fontweight='bold')
ax2.grid(axis='y', alpha=0.3)

# Plot 3: Top 15 Exposure-Disease pairs
ax3 = axes[1, 0]
top15 = results_sorted.head(15)
y_pos = np.arange(len(top15))
labels = [f"{row['Exposure_Name'][:15]}→{row['Disease_Name'][:15]}" 
          for _, row in top15.iterrows()]
ax3.barh(y_pos, top15['PDS_Weighted'], color='mediumseagreen', alpha=0.8)
ax3.set_yticks(y_pos)
ax3.set_yticklabels(labels, fontsize=9)
ax3.set_xlabel('PDS Weighted Score', fontsize=12)
ax3.set_title('Top 15 Exposure-Disease Pairs', fontsize=14, fontweight='bold')
ax3.invert_yaxis()
ax3.grid(axis='x', alpha=0.3)

# Plot 4: Path count vs PDS_Weighted scatter plot
ax4 = axes[1, 1]
scatter = ax4.scatter(results_df['Num_Paths'], results_df['PDS_Weighted'], 
                     c=results_df['PDS_Normalized'], cmap='viridis', 
                     alpha=0.6, s=50, edgecolors='black', linewidth=0.5)
ax4.set_xlabel('Number of Paths', fontsize=12)
ax4.set_ylabel('PDS Weighted Score', fontsize=12)
ax4.set_title('Path Count vs PDS Weighted Score', fontsize=14, fontweight='bold')
ax4.grid(alpha=0.3)
cbar = plt.colorbar(scatter, ax=ax4)
cbar.set_label('PDS Normalized', fontsize=10)

plt.tight_layout()
plot_file = os.path.join(results_dir, 'path_diversity_score_analysis.png')
plt.savefig(plot_file, dpi=300, bbox_inches='tight')
print(f"   Visualization plots saved: {plot_file}")

# 8. Generate summary statistics by exposure and disease
print("\n8. Generating summary statistics for exposures and diseases...")

# Aggregate by exposure
exposure_summary = results_df.groupby(['Exposure_ID', 'Exposure_Name']).agg({
    'Disease_ID': 'count',
    'Num_Paths': 'sum',
    'PDS_Weighted': 'sum'
}).rename(columns={
    'Disease_ID': 'Num_Diseases',
    'Num_Paths': 'Total_Paths',
    'PDS_Weighted': 'Total_PDS_Weighted'
}).reset_index()

exposure_summary = exposure_summary.sort_values('Total_PDS_Weighted', ascending=False)
exposure_summary_file = os.path.join(results_dir, 'exposure_summary_scores.csv')
exposure_summary.to_csv(exposure_summary_file, index=False, encoding='utf-8-sig')
print(f"   Exposure summary saved: {exposure_summary_file}")

# Aggregate by disease
disease_summary = results_df.groupby(['Disease_ID', 'Disease_Name']).agg({
    'Exposure_ID': 'count',
    'Num_Paths': 'sum',
    'PDS_Weighted': 'sum'
}).rename(columns={
    'Exposure_ID': 'Num_Exposures',
    'Num_Paths': 'Total_Paths',
    'PDS_Weighted': 'Total_PDS_Weighted'
}).reset_index()

disease_summary = disease_summary.sort_values('Total_PDS_Weighted', ascending=False)
disease_summary_file = os.path.join(results_dir, 'disease_summary_scores.csv')
disease_summary.to_csv(disease_summary_file, index=False, encoding='utf-8-sig')
print(f"   Disease summary saved: {disease_summary_file}")

# Display Top 10 exposures
print("\n   Top 10 Exposures (by Total_PDS_Weighted):")
print("   " + "-" * 80)
for idx, row in exposure_summary.head(10).iterrows():
    print(f"   {row['Exposure_Name'][:40]:<42} | Diseases: {row['Num_Diseases']:<3} | "
          f"Paths: {row['Total_Paths']:<4} | Score: {row['Total_PDS_Weighted']:.2f}")

# Display Top 10 diseases
print("\n   Top 10 Diseases (by Total_PDS_Weighted):")
print("   " + "-" * 80)
for idx, row in disease_summary.head(10).iterrows():
    print(f"   {row['Disease_Name'][:40]:<42} | Exposures: {row['Num_Exposures']:<3} | "
          f"Paths: {row['Total_Paths']:<4} | Score: {row['Total_PDS_Weighted']:.2f}")

print("\n" + "=" * 80)
print("Calculation completed!")
print("=" * 80)
print("\nOutput files:")
print(f"  1. {output_file}")
print(f"  2. {top50_file}")
print(f"  3. {exposure_summary_file}")
print(f"  4. {disease_summary_file}")
print(f"  5. {plot_file}")
print("\nScore descriptions:")
print("  - Num_Paths: Number of pathways from exposure to disease")
print("  - PDS_Simple: Simple path count score (equals Num_Paths)")
print("  - PDS_Weighted: Weighted score (considering protein degree)")
print("  - PDS_Normalized: Normalized score (PDS_Weighted / Num_Paths)")
print("=" * 80)
