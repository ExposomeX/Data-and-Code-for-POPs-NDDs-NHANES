#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Tidy EPPD_nodes.csv by correcting EXID and Preferred name based on id_corrected.xlsx
"""

import os
import sys
import pandas as pd

# Set UTF-8 encoding for output
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

def main():
    # Find the ebio_summary folder
    current_dir = os.getcwd()
    ebio_folders = [f for f in os.listdir(current_dir) if f.startswith('ebio_summary_') and os.path.isdir(f)]
    
    if not ebio_folders:
        raise FileNotFoundError("No folder starting with 'ebio_summary_' found in current directory")
    
    if len(ebio_folders) > 1:
        print(f"Warning: Multiple ebio_summary folders found: {ebio_folders}")
        print(f"Using the first one: {ebio_folders[0]}")
    
    ebio_folder = ebio_folders[0]
    buildmodel_path = os.path.join(ebio_folder, 'buildModel')
    
    if not os.path.exists(buildmodel_path):
        raise FileNotFoundError(f"buildModel folder not found in {ebio_folder}")
    
    print(f"Using folder: {ebio_folder}")
    print(f"BuildModel path: {buildmodel_path}\n")
    
    # File paths
    id_corrected_file = 'id_corrected.xlsx'
    EPPD_nodes_file = os.path.join(buildmodel_path, 'EPPD_nodes.csv')
    EPPD_edges_file = os.path.join(buildmodel_path, 'EPPD_edges.csv')
    nodes_output_file = os.path.join(buildmodel_path, 'EPPD_nodes_corrected.csv')
    edges_output_file = os.path.join(buildmodel_path, 'EPPD_edges_corrected.csv')
    
    # Read id_corrected.xlsx
    print(f"Reading {id_corrected_file}...")
    id_corrected = pd.read_excel(id_corrected_file)
    print(f"Loaded {len(id_corrected)} rows from id_corrected.xlsx")
    
    # Create mapping dictionaries
    # exid -> unified_id mapping
    exid_to_unified = dict(zip(id_corrected['exid'], id_corrected['unified_id']))
    # preferred_name -> unified_name mapping
    name_to_unified = dict(zip(id_corrected['preferred_name'], id_corrected['unified_name']))
    
    print(f"Created {len(exid_to_unified)} EXID mappings")
    print(f"Created {len(name_to_unified)} name mappings")
    
    # ========== Process EPPD_nodes.csv ==========
    print(f"\n{'='*60}")
    print("Processing EPPD_nodes.csv")
    print('='*60)
    
    # Read EPPD_nodes.csv
    print(f"Reading {EPPD_nodes_file}...")
    EPPD_nodes = pd.read_csv(EPPD_nodes_file)
    print(f"Loaded {len(EPPD_nodes)} rows from EPPD_nodes.csv")
    
    # Replace EXID column values
    print("\nReplacing EXID values...")
    original_exid_count = EPPD_nodes['EXID'].nunique()
    EPPD_nodes['EXID'] = EPPD_nodes['EXID'].map(exid_to_unified).fillna(EPPD_nodes['EXID'])
    new_exid_count = EPPD_nodes['EXID'].nunique()
    print(f"EXID unique values: {original_exid_count} -> {new_exid_count}")
    
    # Replace Preferred name column values
    print("Replacing Preferred name values...")
    original_name_count = EPPD_nodes['Preferred name'].nunique()
    EPPD_nodes['Preferred name'] = EPPD_nodes['Preferred name'].map(name_to_unified).fillna(EPPD_nodes['Preferred name'])
    new_name_count = EPPD_nodes['Preferred name'].nunique()
    print(f"Preferred name unique values: {original_name_count} -> {new_name_count}")
    
    # Save corrected nodes file
    print(f"\nSaving corrected nodes file to {nodes_output_file}...")
    EPPD_nodes.to_csv(nodes_output_file, index=False)
    print(f"Successfully saved {len(EPPD_nodes)} rows")
    
    # Display sample of corrected data
    print("\nFirst 5 rows of corrected nodes data:")
    print(EPPD_nodes[['EXID', 'Preferred name']].head())
    
    # ========== Process EPPD_edges.csv ==========
    print(f"\n{'='*60}")
    print("Processing EPPD_edges.csv")
    print('='*60)
    
    # Read EPPD_edges.csv
    print(f"Reading {EPPD_edges_file}...")
    EPPD_edges = pd.read_csv(EPPD_edges_file)
    print(f"Loaded {len(EPPD_edges)} rows from EPPD_edges.csv")
    
    # Replace Source column values
    print("\nReplacing Source values...")
    original_source_count = EPPD_edges['Source'].nunique()
    EPPD_edges['Source'] = EPPD_edges['Source'].map(exid_to_unified).fillna(EPPD_edges['Source'])
    new_source_count = EPPD_edges['Source'].nunique()
    print(f"Source unique values: {original_source_count} -> {new_source_count}")
    
    # Replace Source preferred name column values
    print("Replacing Source preferred name values...")
    original_source_name_count = EPPD_edges['Source preferred name'].nunique()
    EPPD_edges['Source preferred name'] = EPPD_edges['Source preferred name'].map(name_to_unified).fillna(EPPD_edges['Source preferred name'])
    new_source_name_count = EPPD_edges['Source preferred name'].nunique()
    print(f"Source preferred name unique values: {original_source_name_count} -> {new_source_name_count}")
    
    # Replace Target column values
    print("\nReplacing Target values...")
    original_target_count = EPPD_edges['Target'].nunique()
    EPPD_edges['Target'] = EPPD_edges['Target'].map(exid_to_unified).fillna(EPPD_edges['Target'])
    new_target_count = EPPD_edges['Target'].nunique()
    print(f"Target unique values: {original_target_count} -> {new_target_count}")
    
    # Replace Target preferred name column values
    print("Replacing Target preferred name values...")
    original_target_name_count = EPPD_edges['Target preferred name'].nunique()
    EPPD_edges['Target preferred name'] = EPPD_edges['Target preferred name'].map(name_to_unified).fillna(EPPD_edges['Target preferred name'])
    new_target_name_count = EPPD_edges['Target preferred name'].nunique()
    print(f"Target preferred name unique values: {original_target_name_count} -> {new_target_name_count}")
    
    # Save corrected edges file
    print(f"\nSaving corrected edges file to {edges_output_file}...")
    EPPD_edges.to_csv(edges_output_file, index=False)
    print(f"Successfully saved {len(EPPD_edges)} rows")
    
    # Display sample of corrected data
    print("\nFirst 5 rows of corrected edges data:")
    print(EPPD_edges[['Source', 'Source preferred name', 'Target', 'Target preferred name']].head())
    
    print(f"\n{'='*60}")
    print("Processing completed successfully!")
    print('='*60)

if __name__ == '__main__':
    main()
